package arrayList;

public class ArrayList<T>{
	
	public ArrayList(int capacity){
		
	}
	
	public ArrayList(){
	}

	
	public int getCount() {
		return 0;
	}


	public T get(int index) {
		return null;
	}


	public void add(T element) {

	}

	public T removeAt(int index) {
		return null;
	}
	

	public void set(int i, T item) {

	}
	
}
