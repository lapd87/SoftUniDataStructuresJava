 
import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by IntelliJ IDEA.
 * User: LAPD
 * Date: 26.1.2019 г.
 * Time: 18:22 ч.
 */
public class TextEditorImpl implements TextEditor {

    private Map<String, Boolean> userIsLogged;
    private Trie<Deque<StringBuilder>> userTexts;

    public TextEditorImpl() {
        this.userIsLogged = new LinkedHashMap<>();
        this.userTexts = new Trie<>();
    }


    private boolean isNotLogged(String username) {
        return !this.userIsLogged.containsKey(username)
                || !this.userIsLogged.get(username);
    }

    @Override
    public void login(String username) {

       
        if (!isNotLogged(username)) {
            this.clear(username);
            return;
        }

        Deque<StringBuilder> textChanges = new ArrayDeque<>();
        textChanges.push(new StringBuilder());

        this.userTexts.insert(username, textChanges);

        this.userIsLogged.put(username, true);
    }

    @Override
    public void logout(String username) {
        if (isNotLogged(username)) return;

        Deque<StringBuilder> textChanges = new ArrayDeque<>();
        textChanges.push(new StringBuilder());
        this.userTexts.insert(username, textChanges);

        this.userIsLogged.put(username, false);
    }

    @Override
    public void prepend(String username, String string) {
        this.insert(username, 0, string);
    }

    @Override
    public void insert(String username, int index, String string) {
        if (isNotLogged(username)) return;

        Deque<StringBuilder> textsValue = this.userTexts
                .getValue(username);
        StringBuilder lastValue = textsValue.peek();

        try {
            assert lastValue != null;
            lastValue.insert(index, string
                    .replace("\"", ""));
            textsValue.push(lastValue);
        } catch (StringIndexOutOfBoundsException ignored) {
            ;
        }
    }

    @Override
    public void substring(String username, int startIndex, int length) {
        if (isNotLogged(username)) return;

        Deque<StringBuilder> textsValue = this.userTexts
                .getValue(username);
        StringBuilder lastValue = textsValue.peek();

        try {
            assert lastValue != null;
            String substring = lastValue
                    .substring(startIndex, startIndex + length);
            textsValue.push(new StringBuilder(substring));
        } catch (StringIndexOutOfBoundsException ignored) {
            ;
        }
    }

    @Override
    public void delete(String username, int startIndex, int length) {
        if (isNotLogged(username)) return;

        Deque<StringBuilder> textsValue = this.userTexts
                .getValue(username);
        StringBuilder lastValue = textsValue.peek();

        try {
            assert lastValue != null;
            StringBuilder replaced = lastValue
                    .replace(startIndex, startIndex + length, "");
            textsValue.push(replaced);
        } catch (StringIndexOutOfBoundsException ignored) {
            ;
        }
    }

    @Override
    public void clear(String username) {
        this.substring(username, 0, 0);
    }

    @Override
    public int length(String username) {
        return this.print(username).length();
    }

    @Override
    public String print(String username) {
        if (isNotLogged(username)) return "";

        Deque<StringBuilder> textsValue = this.userTexts
                .getValue(username);
        StringBuilder lastValue = textsValue.peek();

        assert lastValue != null;
        return lastValue.toString();
    }

    @Override
    public void undo(String username) {
        if (isNotLogged(username)) return;

        Deque<StringBuilder> textsValue = this.userTexts
                .getValue(username);

        if (textsValue.size() > 1) {
            textsValue.pop();
        }
    }

    @Override
    public Iterable<String> users(String prefix) {

        List<String> loggedUsersByTime = this.userIsLogged.entrySet()
                .stream()
                .filter(Map.Entry::getValue)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());

        if (prefix.isEmpty()) {
            return loggedUsersByTime;
        }

        Trie<String> users = new Trie<>();
        loggedUsersByTime.forEach(u -> users.insert(u, ""));

        Iterable<String> usersByPrefix = users.getByPrefix(prefix);

        Collection<String> usersByPrefixCollection = new ArrayList<>();
        usersByPrefix.forEach(usersByPrefixCollection::add);

        loggedUsersByTime.removeIf(u -> !usersByPrefixCollection.contains(u));

        return loggedUsersByTime;
    }
}