package test.helpers;

import java.util.Random;

public class BasePerformanceTest extends BaseTest {

    protected Random random = new Random();
}
