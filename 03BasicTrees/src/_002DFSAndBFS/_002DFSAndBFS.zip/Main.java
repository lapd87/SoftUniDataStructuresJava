
/**
 * Created by IntelliJ IDEA.
 * User: LAPD
 * Date: 13.1.2019 г.
 * Time: 13:07 ч.
 */
public class Main {
    public static void main(String[] args) {

    }
}