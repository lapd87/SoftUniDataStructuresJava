
/**
 * Created by IntelliJ IDEA.
 * User: LAPD
 * Date: 17.1.2019 г.
 * Time: 16:27 ч.
 */
public class Main {
    public static void main(String[] args) {

    }
}