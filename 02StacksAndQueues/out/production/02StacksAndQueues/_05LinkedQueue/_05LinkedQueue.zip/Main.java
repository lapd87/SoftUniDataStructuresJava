
/**
 * Created by IntelliJ IDEA.
 * User: LAPD
 * Date: 10.1.2019 г.
 * Time: 15:52 ч.
 */
public class Main {
    public static void main(String[] args) {

    }
}